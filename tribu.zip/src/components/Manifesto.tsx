import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'motion/react';

gsap.registerPlugin(ScrollTrigger);

const manifestoItems = [
  {
    traditional: "Most recruitment firms optimize for placement volume.",
    tribu: "We optimize for ",
    highlight: "Retention."
  },
  {
    traditional: "Most agencies invoice and disappear.",
    tribu: "We stay aligned after the hire.",
    highlight: "Accountability."
  },
  {
    traditional: "Most firms send raw CVs.",
    tribu: "We deliver structured dossiers.",
    highlight: "Precision."
  },
  {
    traditional: "Most intermediaries protect opacity.",
    tribu: "We build on ",
    highlight: "Transparency."
  }
];

export function Manifesto() {
  const sectionRef = useRef<HTMLElement>(null);
  const itemsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      itemsRef.current.forEach((item, index) => {
        gsap.fromTo(item,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: "power3.out",
            scrollTrigger: {
              trigger: item,
              start: "top 80%",
              toggleActions: "play none none reverse"
            }
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-40 bg-[var(--color-tribu-bg)] overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-[var(--color-tribu-surface)] rounded-full blur-[200px] opacity-20 -translate-y-1/2 translate-x-1/3" />
      </div>

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <div className="mb-24 text-center">
          <h2 className="text-sm font-mono tracking-[0.2em] text-[var(--color-tribu-muted)] uppercase mb-6">
            The Manifesto
          </h2>
          <p className="text-3xl md:text-5xl font-bold tracking-tighter leading-tight text-balance">
            A system designed by people obsessed with precision, trust, aesthetics, and accountability.
          </p>
        </div>

        <div className="space-y-16 md:space-y-24">
          {manifestoItems.map((item, index) => (
            <div
              key={index}
              ref={el => { if (el) itemsRef.current[index] = el; }}
              className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 group"
            >
              <div className="md:w-5/12">
                <p className="text-lg md:text-xl text-[var(--color-tribu-muted)] leading-relaxed">
                  {item.traditional}
                </p>
              </div>
              
              <div className="hidden md:flex w-2/12 justify-center">
                <div className="w-[1px] h-16 bg-[var(--color-tribu-border)] group-hover:bg-[var(--color-tribu-accent)] transition-colors duration-500" />
              </div>

              <div className="md:w-5/12">
                <p className="text-2xl md:text-3xl font-medium tracking-tight leading-tight">
                  {item.tribu}
                  <span className="text-[var(--color-tribu-accent)] italic font-serif ml-2">{item.highlight}</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
