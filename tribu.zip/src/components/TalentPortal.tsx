import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'motion/react';
import { Briefcase, FileText, Clock, CreditCard, ChevronRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function TalentPortal() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(cardsRef.current,
        { opacity: 0, x: -50 },
        {
          opacity: 1,
          x: 0,
          stagger: 0.1,
          duration: 0.8,
          ease: "power2.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 70%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} id="talent" className="relative py-32 bg-[var(--color-tribu-surface)] border-t border-[var(--color-tribu-border)]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tighter mb-6 leading-tight">
              <span className="text-[var(--color-tribu-muted)] block">Not just placement.</span>
              <span className="text-[var(--color-tribu-text)]">Ongoing partnership.</span>
            </h2>
            <p className="text-lg text-[var(--color-tribu-muted)] leading-relaxed">
              Talent has access to a private space where they can view active missions, access contracts, retrieve documents, and experience more transparency than with traditional agencies.
            </p>
          </div>
          <button className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider hover:text-[var(--color-tribu-accent)] transition-colors group">
            Access Portal
            <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: Briefcase, title: 'Active Missions', desc: 'Track key mission details and alignment goals.' },
            { icon: FileText, title: 'Document Center', desc: 'Access contracts, NDAs, and competency dossiers.' },
            { icon: Clock, title: 'Time Submission', desc: 'Submit worked days and support invoicing workflows.' },
            { icon: CreditCard, title: 'Financial Visibility', desc: 'See important financial and assignment information.' }
          ].map((item, index) => (
            <div
              key={index}
              ref={el => { if (el) cardsRef.current[index] = el; }}
              className="glass-card rounded-2xl p-6 flex flex-col hover:bg-[var(--color-tribu-surface-hover)] transition-colors duration-300 group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-[var(--color-tribu-bg)] border border-[var(--color-tribu-border)] flex items-center justify-center mb-6 group-hover:bg-[var(--color-tribu-accent)] group-hover:text-[var(--color-tribu-bg)] transition-colors duration-300">
                <item.icon className="w-4 h-4" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
              <p className="text-sm text-[var(--color-tribu-muted)] leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

        {/* Minimal Dashboard Fragment */}
        <div className="mt-16 w-full h-[400px] rounded-3xl border border-[var(--color-tribu-border)] bg-[var(--color-tribu-bg)] overflow-hidden relative flex items-center justify-center">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-5 mix-blend-luminosity" />
          <div className="relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[var(--color-tribu-border)] bg-[var(--color-tribu-surface)]/50 backdrop-blur-md mb-4">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-medium tracking-widest uppercase text-[var(--color-tribu-muted)]">Portal Preview</span>
            </div>
            <p className="text-[var(--color-tribu-muted)] font-mono text-sm tracking-widest uppercase">Interactive dashboard simulation</p>
          </div>
        </div>
      </div>
    </section>
  );
}
