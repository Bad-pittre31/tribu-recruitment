import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'motion/react';
import { ArrowUpRight, ShieldCheck, Activity, BrainCircuit } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    id: '01',
    title: 'Pay As They Stay™',
    description: 'Risk-aligned permanent hiring. Clients pay progressively as the hire remains successful and integrated.',
    icon: ShieldCheck,
    tags: ['Milestone-based payment', 'Risk alignment', 'Retention-first model', 'Trust-based economics'],
    visual: 'Diagnostic Shuffler'
  },
  {
    id: '02',
    title: 'Shared Value With Talent',
    description: 'Part of the success generated is redistributed through consultant bonuses and success-based rewards.',
    icon: Activity,
    tags: ['Consultant success bonus', 'Freelance mission-alignment bonus', 'Fairer value distribution', 'Long-term partnership logic'],
    visual: 'Telemetry Typewriter'
  },
  {
    id: '03',
    title: 'AI-Enhanced Delivery',
    description: 'Every candidate is delivered as a structured, premium competency dossier, not just a CV.',
    icon: BrainCircuit,
    tags: ['AI candidate analysis', 'DISC profile automation', 'Matching intelligence', 'Structured competency dossier'],
    visual: 'Cursor Protocol Scheduler'
  }
];

export function Differentiators() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, index) => {
        gsap.fromTo(card,
          { opacity: 0, y: 100, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 1.2,
            ease: "power3.out",
            scrollTrigger: {
              trigger: card,
              start: "top 85%",
              end: "bottom 20%",
              toggleActions: "play none none reverse"
            }
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} id="model" className="relative py-32 bg-[var(--color-tribu-surface)]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-20">
          <h2 className="text-4xl md:text-6xl font-bold tracking-tighter mb-6">
            <span className="text-[var(--color-tribu-muted)] block">The Architecture of</span>
            <span className="text-[var(--color-tribu-text)]">Alignment.</span>
          </h2>
          <p className="text-xl text-[var(--color-tribu-muted)] max-w-2xl">
            We replaced the traditional placement model with a system engineered for retention, transparency, and shared success.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.id}
              ref={el => {
                if (el) cardsRef.current[index] = el;
              }}
              className="glass-card rounded-3xl p-8 flex flex-col h-full group hover:border-[var(--color-tribu-muted)] transition-colors duration-500"
            >
              <div className="flex justify-between items-start mb-12">
                <span className="text-sm font-mono text-[var(--color-tribu-muted)] tracking-widest">{feature.id}</span>
                <div className="w-12 h-12 rounded-full bg-[var(--color-tribu-bg)] flex items-center justify-center border border-[var(--color-tribu-border)] group-hover:bg-[var(--color-tribu-accent)] group-hover:text-[var(--color-tribu-bg)] transition-colors duration-500">
                  <feature.icon className="w-5 h-5" />
                </div>
              </div>

              <h3 className="text-2xl font-bold mb-4 tracking-tight">{feature.title}</h3>
              <p className="text-[var(--color-tribu-muted)] mb-8 flex-grow leading-relaxed">
                {feature.description}
              </p>

              <div className="space-y-3 mb-8">
                {feature.tags.map((tag, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-[var(--color-tribu-muted)]">
                    <div className="w-1.5 h-1.5 rounded-full bg-[var(--color-tribu-border)] group-hover:bg-[var(--color-tribu-accent)] transition-colors duration-500" />
                    <span>{tag}</span>
                  </div>
                ))}
              </div>

              {/* Abstract Visual Representation Placeholder */}
              <div className="mt-auto pt-8 border-t border-[var(--color-tribu-border)]">
                <div className="h-24 rounded-xl bg-[var(--color-tribu-bg)] border border-[var(--color-tribu-border)] overflow-hidden relative flex items-center justify-center group/visual">
                  <span className="text-xs font-mono text-[var(--color-tribu-muted)] uppercase tracking-widest opacity-50 z-10 transition-opacity duration-500 group-hover/visual:opacity-100">
                    {feature.visual}
                  </span>
                  {/* Simulate activity */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[var(--color-tribu-accent)] to-transparent opacity-0 group-hover/visual:opacity-10 group-hover/visual:animate-[pulse_2s_ease-in-out_infinite] transition-opacity duration-1000" />
                  
                  {/* Scanning line effect */}
                  <div className="absolute top-0 left-0 w-full h-[1px] bg-[var(--color-tribu-accent)] opacity-0 group-hover/visual:opacity-20 group-hover/visual:animate-[scan_3s_linear_infinite]" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
