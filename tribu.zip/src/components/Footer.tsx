import React from 'react';
import { motion } from 'motion/react';

export function Footer() {
  return (
    <footer className="relative py-16 bg-[var(--color-tribu-bg)] border-t border-[var(--color-tribu-border)] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-12">
          
          <div className="flex flex-col gap-6">
            <a href="#" className="text-2xl font-bold tracking-tighter text-[var(--color-tribu-text)]">
              TRIBU
            </a>
            <p className="text-sm font-mono text-[var(--color-tribu-muted)] tracking-widest uppercase">
              Hiring that stays.
            </p>
          </div>

          <div className="flex flex-col md:items-end gap-6 text-sm text-[var(--color-tribu-muted)]">
            <div className="flex items-center gap-3">
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--color-tribu-accent)] animate-pulse" />
              <span className="font-mono tracking-widest uppercase">System Operational</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--color-tribu-accent)] animate-pulse" />
              <span className="font-mono tracking-widest uppercase">Retention Protocol Active</span>
            </div>
          </div>

        </div>

        <div className="mt-24 pt-8 border-t border-[var(--color-tribu-border)] flex flex-col md:flex-row justify-between items-center gap-6 text-xs text-[var(--color-tribu-muted)]">
          <p>&copy; {new Date().getFullYear()} TRIBU. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-[var(--color-tribu-text)] transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-[var(--color-tribu-text)] transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-[var(--color-tribu-text)] transition-colors">Legal Mentions</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
