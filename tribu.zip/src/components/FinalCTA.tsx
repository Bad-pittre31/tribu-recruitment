import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'motion/react';
import { MagneticButton } from './ui/MagneticButton';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function FinalCTA() {
  const sectionRef = useRef<HTMLElement>(null);
  const elementsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(elementsRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          stagger: 0.2,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-40 bg-[var(--color-tribu-surface)] overflow-hidden border-t border-[var(--color-tribu-border)]">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-[var(--color-tribu-accent)] rounded-t-full blur-[150px] opacity-[0.03]" />
      </div>

      <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
        <h2 className="text-5xl md:text-7xl font-bold tracking-tighter mb-10 leading-tight" ref={el => { if (el) elementsRef.current[0] = el; }}>
          <span className="text-[var(--color-tribu-muted)] block">Build your team with</span>
          <span className="text-[var(--color-tribu-text)]">more alignment.</span>
        </h2>
        
        <p className="text-xl text-[var(--color-tribu-muted)] mb-16 max-w-2xl mx-auto leading-relaxed" ref={el => { if (el) elementsRef.current[1] = el; }}>
          A premium talent partner combining human recruitment expertise, AI-powered precision, and transparent business models to create hiring relationships that actually last.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6" ref={el => { if (el) elementsRef.current[2] = el; }}>
          <MagneticButton variant="primary" className="w-full sm:w-auto text-sm font-semibold uppercase tracking-wider px-10 py-5">
            Book a strategic call
          </MagneticButton>
          <MagneticButton variant="secondary" className="w-full sm:w-auto group px-10 py-5">
            <span className="text-sm font-semibold uppercase tracking-wider">Explore the model</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </MagneticButton>
        </div>
      </div>
    </section>
  );
}
