import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'motion/react';
import { Target, Search, ShieldCheck } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    id: '01',
    title: 'Calibration',
    description: 'Deep intake, business context, culture alignment, role expectations, and success criteria defined with precision.',
    icon: Target,
    color: 'var(--color-tribu-surface)'
  },
  {
    id: '02',
    title: 'Precision Delivery',
    description: 'Targeted sourcing and structured delivery. AI-powered competency dossier via Miixeo engine. No raw CV forwarding. Only curated, contextualized candidate presentation.',
    icon: Search,
    color: 'var(--color-tribu-surface-hover)'
  },
  {
    id: '03',
    title: 'Retention Protocol 90™',
    description: '30 / 60 / 90 day follow-ups. Integration quality monitored. Alignment secured. Hiring success de-risked over time.',
    icon: ShieldCheck,
    color: 'var(--color-tribu-bg)'
  }
];

export function Protocol() {
  const containerRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, index) => {
        gsap.to(card, {
          scale: 1 - (cardsRef.current.length - index - 1) * 0.05,
          y: (cardsRef.current.length - index - 1) * -20,
          opacity: 1 - (cardsRef.current.length - index - 1) * 0.1,
          scrollTrigger: {
            trigger: card,
            start: "top 20%",
            endTrigger: containerRef.current,
            end: "bottom bottom",
            scrub: true,
            pin: true,
            pinSpacing: false
          }
        });
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={containerRef} id="protocol" className="relative py-32 bg-[var(--color-tribu-bg)]">
      <div className="max-w-4xl mx-auto px-6">
        <div className="mb-20 text-center">
          <h2 className="text-4xl md:text-6xl font-bold tracking-tighter mb-6">
            <span className="text-[var(--color-tribu-muted)] block">The Methodology of</span>
            <span className="text-[var(--color-tribu-text)]">Alignment.</span>
          </h2>
          <p className="text-xl text-[var(--color-tribu-muted)] max-w-2xl mx-auto">
            A structured, three-step protocol designed to de-risk hiring and ensure long-term success.
          </p>
        </div>

        <div className="relative flex flex-col items-center gap-10 pb-[50vh]">
          {steps.map((step, index) => (
            <div
              key={step.id}
              ref={el => { if (el) cardsRef.current[index] = el; }}
              className="w-full max-w-3xl glass-card rounded-3xl p-10 md:p-16 flex flex-col md:flex-row gap-10 items-start shadow-2xl sticky top-[20vh]"
              style={{ zIndex: index, backgroundColor: step.color }}
            >
              <div className="w-16 h-16 rounded-full bg-[var(--color-tribu-bg)] border border-[var(--color-tribu-border)] flex items-center justify-center shrink-0">
                <step.icon className="w-8 h-8 text-[var(--color-tribu-accent)]" />
              </div>
              
              <div>
                <div className="flex items-center gap-4 mb-4">
                  <span className="text-sm font-mono text-[var(--color-tribu-muted)] tracking-widest">STEP {step.id}</span>
                  <div className="h-[1px] w-12 bg-[var(--color-tribu-border)]" />
                </div>
                <h3 className="text-3xl font-bold mb-6 tracking-tight">{step.title}</h3>
                <p className="text-lg text-[var(--color-tribu-muted)] leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
