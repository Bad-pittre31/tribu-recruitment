import React, { useState, useEffect } from 'react';
import { motion, useScroll, useMotionValueEvent } from 'motion/react';
import { MagneticButton } from './ui/MagneticButton';
import { cn } from '@/src/utils/cn';

export function Navbar() {
  const { scrollY } = useScroll();
  const [hidden, setHidden] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useMotionValueEvent(scrollY, "change", (latest) => {
    const previous = scrollY.getPrevious() ?? 0;
    if (latest > previous && latest > 150) {
      setHidden(true);
    } else {
      setHidden(false);
    }
    setIsScrolled(latest > 50);
  });

  return (
    <motion.nav
      variants={{
        visible: { y: 0 },
        hidden: { y: "-100%" },
      }}
      animate={hidden ? "hidden" : "visible"}
      transition={{ duration: 0.35, ease: "easeInOut" }}
      className={cn(
        "fixed top-0 left-0 right-0 z-50 flex justify-center px-6 py-4 transition-all duration-300",
        isScrolled ? "py-4" : "py-8"
      )}
    >
      <div className={cn(
        "flex w-full max-w-7xl items-center justify-between rounded-full px-6 py-3 transition-all duration-500",
        isScrolled ? "glass-panel shadow-lg" : "bg-transparent"
      )}>
        <a href="#" className="text-xl font-bold tracking-tighter text-[var(--color-tribu-text)]">
          TRIBU
        </a>

        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-[var(--color-tribu-muted)]">
          <a href="#model" className="hover:text-[var(--color-tribu-text)] transition-colors">Model</a>
          <a href="#clients" className="hover:text-[var(--color-tribu-text)] transition-colors">Clients</a>
          <a href="#talent" className="hover:text-[var(--color-tribu-text)] transition-colors">Talent</a>
          <a href="#protocol" className="hover:text-[var(--color-tribu-text)] transition-colors">Protocol</a>
        </div>

        <div className="flex items-center gap-4">
          <MagneticButton variant="primary" className="hidden sm:flex px-6 py-2.5 text-xs font-semibold uppercase tracking-wider">
            Book a strategic call
          </MagneticButton>
          <button className="md:hidden text-[var(--color-tribu-text)]">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </button>
        </div>
      </div>
    </motion.nav>
  );
}
