import React, { useEffect, useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { MagneticButton } from './ui/MagneticButton';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  // Mouse glow effect
  const [mousePosition, setMousePosition] = React.useState({ x: 0, y: 0 });
  const handleMouseMove = (e: React.MouseEvent) => {
    const { clientX, clientY } = e;
    const { left, top, width, height } = containerRef.current!.getBoundingClientRect();
    const x = (clientX - left) / width;
    const y = (clientY - top) / height;
    setMousePosition({ x, y });
  };

  return (
    <section
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-32 pb-20"
    >
      {/* Abstract Glowing Background Element */}
      <motion.div
        className="absolute inset-0 z-0 pointer-events-none"
        style={{ y, opacity }}
      >
        <div 
          className="absolute w-[800px] h-[800px] rounded-full blur-[120px] opacity-20 transition-all duration-700 ease-out"
          style={{
            background: 'radial-gradient(circle, var(--color-tribu-accent) 0%, transparent 70%)',
            left: `calc(${mousePosition.x * 100}% - 400px)`,
            top: `calc(${mousePosition.y * 100}% - 400px)`,
          }}
        />
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2069&auto=format&fit=crop')] bg-cover bg-center opacity-10 mix-blend-luminosity" />
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1534706936160-d5ee67737249?q=80&w=1974&auto=format&fit=crop')] bg-cover bg-center opacity-[0.05] mix-blend-overlay" /> {/* Botanical shadow overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[var(--color-tribu-bg)] to-[var(--color-tribu-bg)] opacity-90" />
      </motion.div>

      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
          className="mb-8 inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[var(--color-tribu-border)] bg-[var(--color-tribu-surface)]/50 backdrop-blur-md"
        >
          <span className="w-2 h-2 rounded-full bg-[var(--color-tribu-accent)] animate-pulse" />
          <span className="text-xs font-medium tracking-widest uppercase text-[var(--color-tribu-muted)]">Powered by Miixeo</span>
        </motion.div>

        <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-[0.9] mb-8">
          <motion.span 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
            className="block text-[var(--color-tribu-muted)]"
          >
            Hiring meets
          </motion.span>
          <motion.span 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
            className="block text-[var(--color-tribu-text)]"
          >
            Retention.
          </motion.span>
        </h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.5 }}
          className="max-w-2xl text-lg md:text-xl text-[var(--color-tribu-muted)] mb-12 text-balance leading-relaxed"
        >
          A premium talent partner built on transparency, shared value, and AI-powered precision. We don't optimize for placements. We optimize for durable hiring success.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center gap-6"
        >
          <MagneticButton variant="primary" className="w-full sm:w-auto text-sm font-semibold uppercase tracking-wider">
            Book a strategic call
          </MagneticButton>
          <MagneticButton variant="ghost" className="w-full sm:w-auto group">
            <span className="text-sm font-semibold uppercase tracking-wider">Explore the model</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </MagneticButton>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <div className="w-[1px] h-12 bg-gradient-to-b from-[var(--color-tribu-muted)] to-transparent" />
      </motion.div>
    </section>
  );
}
