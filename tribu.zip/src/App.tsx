/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Differentiators } from './components/Differentiators';
import { AILayer } from './components/AILayer';
import { TalentPortal } from './components/TalentPortal';
import { Manifesto } from './components/Manifesto';
import { Protocol } from './components/Protocol';
import { ClientModel } from './components/ClientModel';
import { Transparency } from './components/Transparency';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[var(--color-tribu-bg)] text-[var(--color-tribu-text)] selection:bg-[var(--color-tribu-accent)] selection:text-[var(--color-tribu-bg)]">
      <div className="noise-overlay" />
      <Navbar />
      <main>
        <Hero />
        <Differentiators />
        <AILayer />
        <TalentPortal />
        <Manifesto />
        <Protocol />
        <ClientModel />
        <Transparency />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
